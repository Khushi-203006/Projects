const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email:    { type: String, required: true, unique: true },
  password: { type: String, required: true }
}, { timestamps: true });

module.exports = mongoose.model('User', UserSchema);
// Add this to your existing User.js model

const voiceFeaturesSchema = new mongoose.Schema({
    sleepHabits: {
        type: { type: String, enum: ['early_bird', 'night_owl', 'moderate'] },
        score: { type: Number, min: 1, max: 10 }
    },
    cleanliness: {
        level: { type: String, enum: ['high', 'moderate', 'low'] },
        score: { type: Number, min: 1, max: 10 }
    },
    studyEnvironment: {
        type: { type: String, enum: ['quiet', 'ambient', 'flexible'] },
        score: { type: Number, min: 1, max: 10 }
    },
    guestFrequency: {
        frequency: { type: String, enum: ['low', 'moderate', 'high'] },
        score: { type: Number, min: 1, max: 10 }
    },
    socialPreference: {
        type: { type: String, enum: ['introverted', 'balanced', 'extroverted'] },
        score: { type: Number, min: 1, max: 10 }
    },
    confidence: { type: Number, min: 0, max: 100 },
    timestamp: { type: Date, default: Date.now }
});

// Add these fields to your existing userSchema
const userSchema = new mongoose.Schema({
    // ... your existing fields ...
    voiceFeatures: voiceFeaturesSchema,
    surveyCompleted: { type: Boolean, default: false },
    surveyCompletedAt: Date,
    // ... rest of your existing fields ...
});

module.exports = mongoose.models.User || mongoose.model('User', UserSchema);
