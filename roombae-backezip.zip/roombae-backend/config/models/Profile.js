const mongoose = require('mongoose');

const ProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  budget: {
    type: Number,
    required: true,
  },
  lifestyle: {
    type: String,
    required: true,
  },
  cleanliness: {
    type: Number,
    required: true,
  },
  wakeUpTime: {
    type: String,
    required: true,
  },
  roomType: {
    type: String,
    required: true,
  }
}, { timestamps: true });

module.exports = mongoose.model('Profile', ProfileSchema);
