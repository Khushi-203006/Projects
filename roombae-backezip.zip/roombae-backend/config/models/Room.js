const mongoose = require('mongoose');

const RoomSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  location: String,
  price: Number,
  description: String,
});

module.exports = mongoose.model('Room', RoomSchema);
