// services/matchingAlgorithm.js
class EnhancedMatchingAlgorithm {
    static calculateCompatibility(user1Features, user2Features) {
        const weights = {
            sleepHabits: 0.25,
            cleanliness: 0.20,
            studyEnvironment: 0.20,
            guestFrequency: 0.15,
            socialPreference: 0.20
        };

        let totalScore = 0;
        let explanations = [];

        // Sleep habits compatibility
        const sleepDiff = Math.abs(user1Features.sleepHabits.score - user2Features.sleepHabits.score);
        const sleepScore = Math.max(0, 100 - (sleepDiff * 10));
        totalScore += sleepScore * weights.sleepHabits;
        
        if (sleepScore > 70) {
            explanations.push("Similar sleep schedules");
        }

        // Cleanliness compatibility
        const cleanDiff = Math.abs(user1Features.cleanliness.score - user2Features.cleanliness.score);
        const cleanScore = Math.max(0, 100 - (cleanDiff * 8));
        totalScore += cleanScore * weights.cleanliness;
        
        if (cleanScore > 80) {
            explanations.push("Compatible cleanliness standards");
        }

        // Study environment
        const studyDiff = Math.abs(user1Features.studyEnvironment.score - user2Features.studyEnvironment.score);
        const studyScore = Math.max(0, 100 - (studyDiff * 12));
        totalScore += studyScore * weights.studyEnvironment;

        // Guest frequency
        const guestDiff = Math.abs(user1Features.guestFrequency.score - user2Features.guestFrequency.score);
        const guestScore = Math.max(0, 100 - (guestDiff * 10));
        totalScore += guestScore * weights.guestFrequency;

        // Social preference
        const socialDiff = Math.abs(user1Features.socialPreference.score - user2Features.socialPreference.score);
        const socialScore = Math.max(0, 100 - (socialDiff * 8));
        totalScore += socialScore * weights.socialPreference;

        return {
            score: Math.round(totalScore),
            explanation: explanations.join(", "),
            breakdown: {
                sleep: Math.round(sleepScore),
                cleanliness: Math.round(cleanScore),
                study: Math.round(studyScore),
                guests: Math.round(guestScore),
                social: Math.round(socialScore)
            }
        };
    }

    static findBestMatches(newUserFeatures, existingUsers, maxMatches = 3) {
        const matches = existingUsers.map(existingUser => {
            const compatibility = this.calculateCompatibility(newUserFeatures, existingUser.voiceFeatures);
            return {
                user: existingUser,
                compatibility
            };
        });

        return matches
            .sort((a, b) => b.compatibility.score - a.compatibility.score)
            .slice(0, maxMatches);
    }
}

module.exports = EnhancedMatchingAlgorithm;