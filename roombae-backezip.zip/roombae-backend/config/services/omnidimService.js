// services/omnidimService.js
const axios = require('axios');

class omnidimService {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseURL = 'https://api.omnidim.io/v1'; // ✅ Replace if needed
    this.headers = {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    };
  }


  async createSurveyAssistant() {
    const assistantConfig = {
      name: "Roommate Compatibility Survey",
      prompt: `You are a friendly voice assistant helping women find compatible roommates for co-living spaces.

Ask these 5 questions in a conversational manner:
1. What are your sleep habits? (early bird/night owl)
2. How clean and organized do you like your living space?
3. Do you prefer a quiet study environment or is some background noise okay?
4. How often do you have guests over?
5. What's your social preference - more alone time or socializing with roommates?

Guidelines:
- Ask one question at a time
- Wait for response before next question
- Be friendly and conversational
- Clarify if answers are unclear
- At the end, summarize their preferences`,
      voice_settings: {
        voice_id: "female_friendly",
        speed: 1.0,
        pitch: 1.0
      }
    };

    try {
      const response = await axios.post(
        `${this.baseURL}/assistants`,
        assistantConfig,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      console.error('Error creating assistant:', error.response?.data || error.message);
      throw error;
    }
  }

  async startVoiceSession(assistantId) {
     try {
      const response = await axios.post(
        `${this.baseURL}/assistants`,
        assistantConfig,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      console.error('Error creating assistant:', error.response?.data || error.message);
      throw error;
    }
  }

  async startVoiceSession(assistantId) {
    try {
      const response = await axios.post(
        `${this.baseURL}/conversations`,
        { assistant_id: assistantId, mode: "voice", auto_start: true },
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      console.error('Error starting session:', error.response?.data || error.message);
      throw error;
    }
  }

  async getTranscript(conversationId) {
    try {
      const response = await axios.get(
        `${this.baseURL}/conversations/${conversationId}/transcript`,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      console.error('Error getting transcript:', error.response?.data || error.message);
      throw error;
    }
  }
}

module.exports = omnidimService;