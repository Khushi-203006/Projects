// services/voiceAnalyzer.js
class VoiceResponseAnalyzer {
    static analyzeResponses(transcript) {
        const responses = transcript.messages || [];
        const userResponses = responses.filter(msg => msg.role === 'user');
        
        const features = {
            sleepHabits: this.extractSleepHabits(userResponses[0]?.content || ''),
            cleanliness: this.extractCleanliness(userResponses[1]?.content || ''),
            studyEnvironment: this.extractStudyPreference(userResponses[2]?.content || ''),
            guestFrequency: this.extractGuestFrequency(userResponses[3]?.content || ''),
            socialPreference: this.extractSocialPreference(userResponses[4]?.content || ''),
            timestamp: new Date(),
            confidence: this.calculateConfidence(userResponses)
        };

        return features;
    }

    static extractSleepHabits(response) {
        const text = response.toLowerCase();
        if (text.includes('early') || text.includes('morning')) {
            return { type: 'early_bird', score: 8 };
        } else if (text.includes('late') || text.includes('night')) {
            return { type: 'night_owl', score: 8 };
        } else {
            return { type: 'moderate', score: 5 };
        }
    }

    static extractCleanliness(response) {
        const text = response.toLowerCase();
        if (text.includes('very clean') || text.includes('organized')) {
            return { level: 'high', score: 9 };
        } else if (text.includes('messy')) {
            return { level: 'low', score: 3 };
        } else {
            return { level: 'moderate', score: 6 };
        }
    }

    static extractStudyPreference(response) {
        const text = response.toLowerCase();
        if (text.includes('quiet') || text.includes('silent')) {
            return { type: 'quiet', score: 8 };
        } else if (text.includes('noise') || text.includes('music')) {
            return { type: 'ambient', score: 7 };
        } else {
            return { type: 'flexible', score: 5 };
        }
    }

    static extractGuestFrequency(response) {
        const text = response.toLowerCase();
        if (text.includes('never') || text.includes('rarely')) {
            return { frequency: 'low', score: 2 };
        } else if (text.includes('often') || text.includes('frequently')) {
            return { frequency: 'high', score: 8 };
        } else {
            return { frequency: 'moderate', score: 5 };
        }
    }

    static extractSocialPreference(response) {
        const text = response.toLowerCase();
        if (text.includes('alone') || text.includes('private')) {
            return { type: 'introverted', score: 3 };
        } else if (text.includes('social') || text.includes('together')) {
            return { type: 'extroverted', score: 8 };
        } else {
            return { type: 'balanced', score: 5 };
        }
    }

    static calculateConfidence(responses) {
        const totalResponses = responses.length;
        let confidenceScore = totalResponses * 20;
        return Math.min(confidenceScore, 100);
    }
}

module.exports = VoiceResponseAnalyzer;