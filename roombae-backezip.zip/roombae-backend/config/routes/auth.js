// routes/auth.js

const express = require('express');
const router = express.Router();
const { register, login } = require('../controllers/authcontroller');

router.post('/register', register); // ✅ register must be a function
router.post('/login', login);       // ✅ login must be a function

module.exports = router;
