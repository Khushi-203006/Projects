const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profile.controller');

// Route: POST /api/profile/create
router.post('/create', profileController.createProfile);

module.exports = router;
