// routes/match.js
const express = require('express');
const router = express.Router();
const matchController = require('../controllers/matchcontroller');

// Change this line ⬇️
// ✅ Fix
router.post('/find', matchController.findMatches);
 // ✅ POST route

module.exports = router;
