const express = require('express');
const router = express.Router();

// Add admin routes here
router.get('/', (req, res) => {
  res.send('Admin routes placeholder');
});

module.exports = router;
