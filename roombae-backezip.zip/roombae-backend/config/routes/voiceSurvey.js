// routes/voiceSurvey.js
const express = require('express');
const multer = require('multer');

const VoiceResponseAnalyzer = require('../services/voiceAnalyzer');
const EnhancedMatchingAlgorithm = require('../services/matchingAlgorithm');
const User = require('../models/User');
const path = require('path');
console.log('Looking for file at:', path.resolve(__dirname, '../services/omnidimService'));
const OmnidimService = require('../services/omnidimService');
const router = express.Router();
const upload = multer({ dest: 'uploads/' });

// Initialize Omnidim service
const omnidimService = new OmnidimService(process.env.OMNIDIM_API_KEY);

// Start voice survey
router.post('/start', async (req, res) => {
    try {
        const { userId } = req.body;
        
        const assistant = await omnidimService.createSurveyAssistant();
        const session = await omnidimService.startVoiceSession(assistant.id);
        
        res.json({
            success: true,
            sessionId: session.id,
            assistantId: assistant.id,
            message: "Voice survey session started!"
        });
        
    } catch (error) {
        console.error('Voice survey start error:', error);
        res.status(500).json({
            success: false,
            error: "Failed to start voice survey"
        });
    }
});

// Complete survey and find matches
router.post('/complete', async (req, res) => {
    try {
        const { conversationId, userId } = req.body;
        
        const transcript = await omnidimService.getTranscript(conversationId);
        const features = VoiceResponseAnalyzer.analyzeResponses(transcript);
        
        // Save user profile with features
        const user = await User.findByIdAndUpdate(userId, {
            voiceFeatures: features,
            surveyCompleted: true,
            surveyCompletedAt: new Date()
        }, { new: true });
        
        // Find existing users for matching
        const existingUsers = await User.find({
            _id: { $ne: userId },
            surveyCompleted: true,
            voiceFeatures: { $exists: true }
        });
        
        // Find best matches
        const matches = EnhancedMatchingAlgorithm.findBestMatches(features, existingUsers, 3);
        
        res.json({
            success: true,
            userFeatures: features,
            matches: matches.map(match => ({
                userId: match.user._id,
                name: match.user.name,
                compatibilityScore: match.compatibility.score,
                explanation: match.compatibility.explanation,
                breakdown: match.compatibility.breakdown
            }))
        });
        
    } catch (error) {
        console.error('Survey completion error:', error);
        res.status(500).json({
            success: false,
            error: "Failed to complete survey and find matches"
        });
    }
});

module.exports = router;