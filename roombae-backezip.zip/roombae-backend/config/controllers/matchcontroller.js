const Profile = require('../models/Profile');

// Helper to convert profile to vector
const profileToVector = (profile) => {
  return [
    profile.cleanliness,
    profile.lifestyle === 'quiet' ? 0 : profile.lifestyle === 'moderate' ? 0.5 : 1,
    profile.wakeUpTime === 'early' ? 0 : profile.wakeUpTime === 'mid' ? 0.5 : 1,
    profile.roomType === 'single' ? 1 : 0,
    profile.budget / 10000  // normalize budget
  ];
};

// Helper to compute cosine similarity
const cosineSimilarity = (vec1, vec2) => {
  const dot = vec1.reduce((sum, val, i) => sum + val * vec2[i], 0);
  const mag1 = Math.sqrt(vec1.reduce((sum, val) => sum + val * val, 0));
  const mag2 = Math.sqrt(vec2.reduce((sum, val) => sum + val * val, 0));
  return dot / (mag1 * mag2);
};

exports.findMatches = async (req, res) => {
  try {
    const newProfile = req.body;

    const allProfiles = await Profile.find({ userId: { $ne: newProfile.userId } });

    if (allProfiles.length === 0) {
      return res.status(404).json({ message: 'No other profiles to match with.' });
    }

    const newVector = profileToVector(newProfile);
    const matches = [];

    for (const profile of allProfiles) {
      const existingVector = profileToVector(profile);
      const score = cosineSimilarity(newVector, existingVector);

      // Budget range filter ±2000
      const budgetDiff = Math.abs(profile.budget - newProfile.budget);
      if (score >= 0.7 && budgetDiff <= 2000) {
        matches.push({
          profile,
          score: score.toFixed(2),
          reason: generateExplanation(newProfile, profile)
        });
      }
    }

    if (matches.length === 0) {
      return res.status(200).json({ message: 'No high-quality matches found (score < 0.7 or budget mismatch).' });
    }

    // Sort top 3 matches
    matches.sort((a, b) => b.score - a.score);

    res.status(200).json({ topMatches: matches.slice(0, 3) });
  } catch (err) {
    console.error('Match error:', err);
    res.status(500).json({ message: 'Server error during matching' });
  }
};

// Natural language explanation
function generateExplanation(user, match) {
  const reasons = [];

  if (user.lifestyle === match.lifestyle) reasons.push('you both have a similar lifestyle');
  if (user.cleanliness === match.cleanliness) reasons.push('you share the same cleanliness preference');
  if (user.wakeUpTime === match.wakeUpTime) reasons.push('you wake up at similar times');
  if (user.roomType === match.roomType) reasons.push('you prefer the same room type');
  if (Math.abs(user.budget - match.budget) <= 1000) reasons.push('your budgets are almost identical');

  if (reasons.length === 0) return 'Some traits are compatible based on AI scoring.';
  return 'Good match because ' + reasons.join(', ') + '.';
}
