const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const app = express();

// Load env variables
dotenv.config();

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch((err) => console.error('MongoDB connection error:', err));

// ✅ Routes - only ONE declaration per route file
const authRoutes = require('./config/routes/auth');
const userRoutes = require('./config/routes/user.routes');
const profileRoutes = require('./config/routes/profile.routes');
const matchRoutes = require('./config/routes/match');
const adminRoutes = require('./config/routes/admin');
app.use('/api/auth', authRoutes);

// ✅ Mount routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/match', matchRoutes);
app.use('/api/admin', adminRoutes);

// Start serverconst voiceSurveyRoutes = require('./routes/voiceSurvey'); // ✅ Correct

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
// Add this to your existing app.js or server.js
const voiceSurveyRoutes = require('./config/routes/voiceSurvey');

// Add this with your other route definitions
app.use('/api/voice-survey', voiceSurveyRoutes);